    var v1=102
    var v2=3
    var result=(v1/v2)
    if(v2==0){
        alert("erro")
    }
    else{alert(result);

    }
